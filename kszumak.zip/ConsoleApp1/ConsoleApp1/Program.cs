﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int d, i, j, n, p, k;
            string a, b;
            Console.WriteLine("Podaj wysokosc choinki: ");
            n = int.Parse(Console.ReadLine());
            a = "*";
            b = " ";
            d = n;
            for (i = 1; i <= n; i++)
            {
                for (j = 1; j < d; j++)
                {
                    Console.Write(b);
                }
                for (p = 1; p <= i; p++)
                {
                    Console.Write(a);
                }
                for (k = 1; k <= i - 1; k++)
                {
                    Console.Write(a);
                }
                d--;
                Console.WriteLine();
            }
                Console.ReadKey();
        }
    }
}
